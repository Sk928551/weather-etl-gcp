import requests
from google.cloud import bigquery
from datetime import datetime
from config import PROJECT_ID, DATASET_ID, TABLE_ID, API_KEY, CITY

def fetch_weather_data(request):
    url = f"https://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    data = response.json()

    if response.status_code != 200:
        return f"Error fetching weather data: {data}"

    weather_record = {
        "timestamp": datetime.utcnow().isoformat(),
        "city": CITY,
        "temp": data["main"]["temp"],
        "humidity": data["main"]["humidity"],
        "weather": data["weather"][0]["main"]
    }

    client = bigquery.Client(project=PROJECT_ID)
    table_ref = f"{PROJECT_ID}.{DATASET_ID}.{TABLE_ID}"
    errors = client.insert_rows_json(table_ref, [weather_record])

    if errors:
        return f"Error inserting rows: {errors}"
    return "Weather data inserted successfully!"